
import mongoose from "mongoose";
import Customer from "../models/customer.model.js";
import CustomerLedger from "../models/customer_ledger.model.js";
import CustomerReturn from "../models/customer_return.model.js";
import CustomerReturnItem from "../models/customer_return_item.model.js";
import Sale from "../models/sale.model.js";
import PaymentAllocation from "../models/payment_allocation.model.js";
import CustomerReturnCounter from "../models/customer_return_counter.model.js";
import CustomerReturnAllocation from "../models/customer_return_allocation.model.js";
import Product from "../models/product.model.js";
import StockManagement from "../models/stock_management.model.js";

export const createCustomerReturn = async (req, res) => {
  const session = await mongoose.startSession();
  let transactionStarted = false;

  try {
    const companyId = req.user.company_id;
    const userId = req.user._id;

    const { customer_id, items, description = "" } = req.body;

    if (!customer_id || !mongoose.isValidObjectId(customer_id)) {
      return res.status(400).json({
        success: false,
        message: "A valid customer is required for a return",
      });
    }

    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({
        success: false,
        message: "At least one return item is required",
      });
    }

    session.startTransaction();
    transactionStarted = true;

    const customer = await Customer.findOne({
      _id: customer_id,
      company_id: companyId,
      is_active: true,
    }).session(session);

    if (!customer) {
      await session.abortTransaction();
      transactionStarted = false;

      return res.status(404).json({
        success: false,
        message: "Customer not found",
      });
    }

// Protect the customer account from concurrent updates.

const customerVersion = Number(customer.account_version || 0);

const customerVersionFilter = {
  _id: customer._id,
  company_id: companyId,
  ...(customer.account_version == null
    ? {
        $or: [
          { account_version: { $exists: false } },
          { account_version: null },
        ],
      }
    : { account_version: customerVersion }),
};

const customerVersionUpdate = await Customer.updateOne(
  customerVersionFilter,
  {
    $inc: {
      account_version: 1,
    },
  },
  {
    session,
  }
);

if (customerVersionUpdate.modifiedCount !== 1) {
  throw new Error(
    "Customer account was updated by another transaction. Please try again."
  );
}

    const preparedItems = [];
    let totalAmount = 0;

    for (const item of items) {
      const qty = Number(item.qty);
      const price = Number(item.price);

      if (!Number.isFinite(qty) || qty <= 0) {
        await session.abortTransaction();
        transactionStarted = false;

        return res.status(400).json({
          success: false,
          message: "Return quantity must be greater than zero",
        });
      }

      if (!Number.isFinite(price) || price < 0) {
        await session.abortTransaction();
        transactionStarted = false;

        return res.status(400).json({
          success: false,
          message: "Return rate cannot be negative",
        });
      }

      const amount = Math.round(qty * price * 100) / 100;
      totalAmount += amount;

 const productId = item.product_id || null;

if (productId && !mongoose.isValidObjectId(productId)) {
  throw new Error("Invalid product ID in return item");
}

preparedItems.push({
  company_id: companyId,
  product_id: productId,
  description: String(
    item.product_name ||
      item.item_name ||
      item.name ||
      item.product ||
      item.description ||
      ""
  ).trim(),
  qty,
  price,
  amount,
});
    }

    totalAmount = Math.round(totalAmount * 100) / 100;

    if (totalAmount <= 0) {
      await session.abortTransaction();
      transactionStarted = false;

      return res.status(400).json({
        success: false,
        message: "Return amount must be greater than zero",
      });
    }

// Calculate outstanding using actual payment and return allocations.

// 1. Get all customer invoices.
const sales = await Sale.find({
  company_id: companyId,
  customer_id,
})
  .session(session)
  .lean();

const saleIds = sales.map((sale) => sale._id);

// 2. Get payment allocations against invoices.
const paymentAllocations = saleIds.length
  ? await PaymentAllocation.find({
      company_id: companyId,
      sale_id: { $in: saleIds },
    })
      .session(session)
      .lean()
  : [];

const invoicePayments = paymentAllocations.reduce(
  (sum, allocation) =>
    sum + Number(allocation.amount || 0),
  0
);

// 3. Get previous customer returns.
const previousReturns = await CustomerReturn.find({
  company_id: companyId,
  customer_id,
})
  .session(session)
  .select("_id")
  .lean();

const previousReturnIds = previousReturns.map(
  (returnRecord) => returnRecord._id
);

// 4. Get only return amounts allocated to invoices.
const previousReturnAllocations =
  previousReturnIds.length && saleIds.length
    ? await CustomerReturnAllocation.find({
        company_id: companyId,
        return_id: { $in: previousReturnIds },
        sale_id: { $in: saleIds },
      })
        .session(session)
        .lean()
    : [];

const invoiceReturns = previousReturnAllocations.reduce(
  (sum, allocation) =>
    sum + Number(allocation.amount || 0),
  0
);

// 5. Get payments applied to the opening balance.
const openingBalancePayments = await CustomerLedger.find({
  company_id: companyId,
  customer_id,
  type: "PAYMENT",
  sale_id: null,
  description: "Payment against opening balance",
})
  .session(session)
  .lean();

const openingBalancePaid = openingBalancePayments.reduce(
  (sum, entry) =>
    sum + Number(entry.credit || 0),
  0
);

// 6. Calculate remaining opening balance.
// Unallocated return credit is NOT deducted here.
const openingBalance = Number(customer.opening_balance || 0);

const remainingOpeningBalance = Math.max(
  0,
  openingBalance - openingBalancePaid
);

// 7. Calculate invoice outstanding after allocated payments and returns.
const totalSales = sales.reduce(
  (sum, sale) =>
    sum + Number(sale.total_amount || 0),
  0
);

const invoiceOutstanding = Math.max(
  0,
  totalSales - invoicePayments - invoiceReturns
);

// 8. Final customer outstanding.
const currentOutstanding = Math.max(
  0,
  Math.round(
    (
      remainingOpeningBalance +
      invoiceOutstanding
    ) * 100
  ) / 100
);


    if (totalAmount > currentOutstanding + 0.000001) {
      await session.abortTransaction();
      transactionStarted = false;

      return res.status(400).json({
        success: false,
        message: `Return amount ₹${totalAmount.toFixed(
          2
        )} exceeds customer outstanding ₹${currentOutstanding.toFixed(2)}`,
        data: {
          outstanding: currentOutstanding,
          return_amount: totalAmount,
        },
      });
    }

// Generate a company-scoped return number atomically.
const counter = await CustomerReturnCounter.findOneAndUpdate(
  { company_id: companyId },
  { $inc: { next_number: 1 } },
  {
    new: true,
    upsert: true,
    setDefaultsOnInsert: false,
    session,
  }
);

const returnNo = `RET-${String(counter.next_number).padStart(5, "0")}`;




    const [returnRecord] = await CustomerReturn.create(
      [
        {
          company_id: companyId,
          customer_id,
          return_no: returnNo,
          return_mode: "CALCULATOR",
          subtotal: totalAmount,
          total_amount: totalAmount,
          description: String(description).trim(),
          created_by: userId,
        },
      ],
      { session }
    );

    await CustomerReturnItem.insertMany(
      preparedItems.map((item) => ({
        ...item,
        return_id: returnRecord._id,
      })),
      { session }
    );



    // DEBUG: Check whether returned items have product IDs.
    console.log(
      "RETURN STOCK DEBUG:",
      preparedItems.map((item) => ({
        product_id: item.product_id,
        description: item.description,
        qty: item.qty,
      }))
    );

    // Increase stock for returned Product POS items.
    // Calculator items without a product_id are skipped.
    for (const item of preparedItems) {
      if (!item.product_id) {
        console.log(
          "RETURN STOCK SKIPPED: missing product_id",
          item.description
        );
        continue;
      }


  const product = await Product.findOne({
    _id: item.product_id,
    company_id: companyId,
  }).session(session);

  if (!product) {
    throw new Error(
      `Product ${item.product_id} not found in this company`
    );
  }

  let stock = await StockManagement.findOne({
    product_id: product._id,
    company_id: companyId,
  }).session(session);

  if (!stock) {
    stock = new StockManagement({
      product_id: product._id,
      company_id: companyId,
      in: 0,
      out: 0,
      total_stock: 0,
    });
  }

  // Add returned quantity to stock received.
  stock.in = Number(stock.in || 0) + item.qty;

  // The StockManagement model recalculates total_stock on save.
  await stock.save({ session });
}

    // Allocate the return against oldest unpaid invoices first (FIFO).
    const salePayments = await PaymentAllocation.find({
      company_id: companyId,
      sale_id: { $in: saleIds },
    })
      .session(session)
      .lean();

    const returnAllocations = await CustomerReturnAllocation.find({
      company_id: companyId,
      sale_id: { $in: saleIds },
    })
      .session(session)
      .lean();

    const paymentsBySale = new Map();
    for (const allocation of salePayments) {
      const key = String(allocation.sale_id);
      paymentsBySale.set(
        key,
        (paymentsBySale.get(key) || 0) + Number(allocation.amount || 0)
      );
    }

    const returnsBySale = new Map();
    for (const allocation of returnAllocations) {
      const key = String(allocation.sale_id);
      returnsBySale.set(
        key,
        (returnsBySale.get(key) || 0) + Number(allocation.amount || 0)
      );
    }

    // Oldest invoice first.
    const fifoSales = [...sales].sort(
      (a, b) =>
        new Date(a.invoice_date || a.createdAt).getTime() -
        new Date(b.invoice_date || b.createdAt).getTime()
    );

    let returnAmountToAllocate = totalAmount;
    const newReturnAllocations = [];

    for (const sale of fifoSales) {
      if (returnAmountToAllocate <= 0.000001) break;

      const saleKey = String(sale._id);
      const invoiceTotal = Number(sale.total_amount || 0);
      const alreadyPaid = paymentsBySale.get(saleKey) || 0;
      const alreadyReturned = returnsBySale.get(saleKey) || 0;

      const invoiceOutstanding = Math.max(
        0,
        Math.round(
          (invoiceTotal - alreadyPaid - alreadyReturned) * 100
        ) / 100
      );

      if (invoiceOutstanding <= 0.000001) continue;

      const amountToAllocate = Math.round(
        Math.min(returnAmountToAllocate, invoiceOutstanding) * 100
      ) / 100;

      if (amountToAllocate <= 0) continue;

      newReturnAllocations.push({
        company_id: companyId,
        return_id: returnRecord._id,
        sale_id: sale._id,
        amount: amountToAllocate,
      });

      returnAmountToAllocate = Math.round(
        (returnAmountToAllocate - amountToAllocate) * 100
      ) / 100;
    }

    if (newReturnAllocations.length > 0) {
      await CustomerReturnAllocation.insertMany(newReturnAllocations, {
        session,
      });
    }

    const allocatedReturnAmount = Math.round(
      (totalAmount - returnAmountToAllocate) * 100
    ) / 100;


    await CustomerLedger.create(
      [
        {
          company_id: companyId,
          customer_id,
          type: "RETURN",
          return_id: returnRecord._id,
          debit: 0,
          credit: totalAmount,
          description: `Return ${returnNo}`,
          transaction_date: returnRecord.return_date,
        },
      ],
      { session }
    );

    await session.commitTransaction();
    transactionStarted = false;

    return res.status(201).json({
      success: true,
      message: "Customer return created successfully",
      data: {
        return_id: returnRecord._id,
        return_no: returnRecord.return_no,
        customer_id: returnRecord.customer_id,
        total_amount: totalAmount,
        outstanding_after_return: Math.round(
          (currentOutstanding - totalAmount) * 100
        ) / 100,
      },
    });

} catch (error) {
  console.error("Create customer return error:", error);
  console.error("Error stack:", error.stack);

  if (transactionStarted) {
    try {
      await session.abortTransaction();
    } catch (abortError) {
      console.error("Return transaction abort error:", abortError);
    }
  }

  return res.status(500).json({
    success: false,
    message: "Failed to create customer return",
    error: error.message,
  });

  } finally {
    await session.endSession();
  }
};






export const getCustomerReturns = async (req, res) => {
  try {
    const companyId = req.user.company_id;
    const { customer_id } = req.query;

    // Always restrict returns to the authenticated company.
    const filter = {
      company_id: companyId,
    };

    // Preserve the existing customer-specific filtering.
    if (customer_id) {
      if (!mongoose.isValidObjectId(customer_id)) {
        return res.status(400).json({
          success: false,
          message: "A valid customer_id is required",
        });
      }

      const customer = await Customer.findOne({
        _id: customer_id,
        company_id: companyId,
      }).select("_id");

      if (!customer) {
        return res.status(404).json({
          success: false,
          message: "Customer not found",
        });
      }

      filter.customer_id = customer._id;
    }

    // Fetch returns newest first.
    const returns = await CustomerReturn.find(filter)
      .populate("customer_id")
      .sort({ createdAt: -1, return_date: -1 })
      .lean();

    const returnIds = returns.map((item) => item._id);

    // Fetch all return items in one query.
    const returnItems = returnIds.length
      ? await CustomerReturnItem.find({
          company_id: companyId,
          return_id: { $in: returnIds },
        }).lean()
      : [];

    const itemsByReturn = new Map();

    for (const item of returnItems) {
      const key = String(item.return_id);

      if (!itemsByReturn.has(key)) {
        itemsByReturn.set(key, []);
      }

      itemsByReturn.get(key).push(item);
    }

    const data = returns.map((item) => ({
      ...item,
      type: "return",
      amount: Number(item.total_amount || 0),
      items: itemsByReturn.get(String(item._id)) || [],
    }));

    return res.status(200).json({
      success: true,
      data,
    });
  } catch (error) {
    console.error("Get customer returns error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch customer returns",
      error: error.message,
    });
  }
};